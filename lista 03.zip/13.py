""" Desenvolva um programa que permite para calcular a soma de número
a partir  do numero 1 até  um número informado pelo usuario. Por exemplo ,
se o usuario  informar o número 5, o programa deverá calcular : 1+2+3+4+5 =15, e mostrar o resultado para o usuario."""

n =input(input( "Digite um numero :"))
a =1
soma =0

whilw a <= n:
 soma = soma+ a
 a +=1


 print( " A soma de 1 até o número que você digitou foi :", soma)

