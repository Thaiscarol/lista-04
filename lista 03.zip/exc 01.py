"""Facça um algoritimo para imprimir 10 vezes o nome do Instituto Federal -Câmpus Rio Preto """

contador =0

while contador < 10:
    print("Instituto Federal de Rio Preto !")

    contador+=1
